﻿using System.Collections.Generic;

namespace IDBTranslateBCP.DbEntity
{
    public interface IDbEntity
    {
        Dictionary<string, object> UserDefinedProperties { get; set; }
    }
}